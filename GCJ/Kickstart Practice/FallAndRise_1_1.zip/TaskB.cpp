#include <bits/stdc++.h>
using namespace std;

int N, M;
double dp[2005][2005];
double den;

double solve(int n, int m){
   if(n == 0){
      if(m != 0) return 0.00;
      return 1.00;
   }
   double &res = dp[n][m];
   if(res != -1.00){
      return res;
   }
   res = 0.00;
   int filledN = N - n;
   int filledM = M - m;
   if(filledN == filledM){
      res = ((n / (double)(n + m)) * solve(n - 1, m));
   }
   else if(filledN > filledM){
      res = (((double)n / (double)(n + m)) * solve(n - 1, m) + ((double)m / (double(m + n))) * (solve(n, m - 1)));
   }
   else{
      return 0.00;
   }
   return res;
}

int _main(int argc, char* argv[]){
   int T;
   cin >> T;
   for(int test = 1; test <= T; ++test){
      scanf("%d%d", &N, &M);
      for(int i = 0; i <= N; ++i){
         for(int j = 0; j <= M; ++j){
            dp[i][j] = -1.00;
         }
      }
      printf("Case #%d: %.12lf\n", test, solve(N, M));
   }
   return 0;
}

//{
int correct(int argc, char *argv[]) {
   return 0;
}
int tests(int argc, char *argv[]) {
   return 0;
}
int main(int argc, char *argv[]) {
   if(argc >= 2 && argv[1][0] == '1') {
      correct(argc, argv);
   } else if(argc >= 2 && argv[1][0] == '2') {
      tests(argc, argv);
   } else {
      _main(argc, argv);
   }
   return 0;
}//}