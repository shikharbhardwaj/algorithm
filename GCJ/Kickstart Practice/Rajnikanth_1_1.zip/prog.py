t = input()
for T in xrange(1,t+1):
    print "Case #"+str(T)+":",
    x,y = map(int,raw_input().split())
    z = float(x-y)
    z /= float(x+y)
    print "%.6f"%z
